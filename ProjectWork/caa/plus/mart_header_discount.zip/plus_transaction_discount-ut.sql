#primary key check
bq query --use_legacy_sql=false <<!
SELECT 
transaction_key,
transaction_line_num,
discount_line_num
FROM
work.plus_transaction_discount
GROUP BY 
transaction_key,
transaction_line_num,
discount_line_num
HAVING COUNT(*)>1
limit 5
!

#null check
bq query --use_legacy_sql=false <<!
SELECT 
count(*)
FROM
work.plus_transaction_discount
where
transaction_key is null or
transaction_line_num is null or
discount_line_num is null
!

#Comparison of transaction count for a single day for LB
bq query --use_legacy_sql=false <<!
SELECT sum(case when edw.transaction_key is null then 0 else 1 end)   as match_count
,sum(case when edw.transaction_key is null then 1 else 0 end)     as orphan_count
FROM `p-asna-analytics-002.analytic_mart.fact_transaction_discount` edl
LEFT OUTER JOIN `work.plus_transaction_discount` edw 
on
edl.transaction_key =edw.transaction_key
and cast(edl.transaction_line_num AS INT64) = cast(edw.transaction_line_num as int64)
and cast(edl.discount_line_num AS INT64) = CAST(edw.discount_line_num AS INT64)
WHERE edl.transaction_dt = '2020-02-16'
and edl.brand_cd ='LB'
!