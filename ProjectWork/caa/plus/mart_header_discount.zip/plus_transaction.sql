create or replace TABLE work.plus_transaction as
SELECT
TO_HEX(MD5(concat(CAST(case when selling_chain_nbr = 7 then 'LB' else 'CA' end as string)
    ,'|',CAST (selling_store_nbr AS string)
    ,'|',CAST (register_nbr AS string)
    ,'|',CAST(transaction_dt as string)
    ,'|',CAST(transaction_nbr AS string)))) as transaction_key
,TO_HEX(MD5(CONCAT(CAST(case when selling_chain_nbr = 7 then 'LB' else 'CA' end as string),'|',cast(customer_nbr as string)))) as brand_customer_key
,TO_HEX(MD5(concat(CAST(case when selling_chain_nbr = 7 then 'LB' else 'CA' end as string),'|',CAST(selling_store_nbr AS string)))) as store_key
,transaction_dt as transaction_dt
,case when order_received_dt is null or trim(order_received_dt)='' then transaction_dt else order_received_dt end as order_dt
,transaction_nbr as transaction_num
,register_nbr as register_num
,sales_channel_type_cd as channel_cd   -- it looks different
,transaction_type_cd as transaction_type_cd
,entry_type_cd as transaction_entry_type_cd
,cashier_nbr as cashier_id
,manager_nbr as store_manager_id
,layaway_nbr as layaway_num
,case when multi_brand_transaction_ind='Y' then 1
      when multi_brand_transaction_ind='N' then 0
      else NULL end as multi_brand_transaction_ind
,case when domestic_order_ind='Y' then 1
      when domestic_order_ind='N' then 0
      else NULL end as domestic_order_ind	  
,case when address_capture_ind='Y' then 1
      when address_capture_ind='N' then 0
      else NULL end as address_capture_ind
,case when email_capture_ind='Y' then 1
      when email_capture_ind='N' then 0
      else NULL end as email_capture_ind
,case when return_receipt_ind='Y' then 1
      when return_receipt_ind='N' then 0
      else NULL end as return_receipt_ind
,order_nbr as order_num
,transaction_void_ind as transaction_void_ind
,case when ship_to_store_nbr is not null and ship_to_store_nbr!='0' and trim(ship_to_store_nbr)!='' then TO_HEX(MD5(concat('LB|',cast(ship_to_store_nbr as string)))) else NULL end as ship_to_store_key
,case when tender_reference_cd is not null and trim(tender_reference_cd) != '0' and trim(tender_reference_cd)!='' then 1 else 0 end as membership_ind
,payment_reference_nbr as plcc_payment_reference_nbr
,null as plcc_payment_line_object_cd
,transaction_tm as plcc_payment_tm   -- Should we pull this from EDW table called SALES_TRANSACTION_PAYMENT
,payment_amt as plcc_payment_amt     -- Should we pull this from EDW table called SALES_TRANSACTION_PAYMENT
,null as p2e_ind
,CURRENT_TIMESTAMP AS edl_create_tms
,'TRANS' AS edl_create_job_nam
,CURRENT_TIMESTAMP AS edl_last_update_tms
,'TRANS' AS edl_last_update_job_nam
,CAST(case when selling_chain_nbr = 7 then 'LB' else 'CA' end as string) as brand_cd
from edl_landing.lb_sales_transaction_header
;
